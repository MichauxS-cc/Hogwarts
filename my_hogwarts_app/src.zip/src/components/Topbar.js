import "../css/Topbar.css";

function Topbar() {
    return (
        <div className="topbar">
            <p className="toptext">Due to COVID, all students will attend classes through Floo Network (Head only transport).</p>
        </div>
    );
}

export default Topbar;
