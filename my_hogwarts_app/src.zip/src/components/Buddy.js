import "../css/Buddy.css";

function Buddy(props) {
    return (
        <div className="buddy-container">
            <div className="buddy-wrapper">
                <img className="buddy-img" src={props.imgURL} alt={props.name} />
                <div className="buddy-name">{props.name}</div>
            </div>
        </div>
    );
}

export default Buddy;
